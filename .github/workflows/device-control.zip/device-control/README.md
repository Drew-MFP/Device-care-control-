# Device Care Control

Native Android app for your phone — same remote-control functionality as
`tablet-switches.html`, no browser needed. Talks to the same Firebase
project the tablets check into.

## Features
- Tablet picker (tablet1–tablet20), remembers your last pick.
- Gatekeep / Repeater remote triggers, each with a confirm dialog and a
  Pending/Confirmed badge.
- A banner at the top when a tablet is currently locked, showing whether a
  remote command, the dead-man timer, or a manual test caused it.
- Pause (minutes + countdown), Disable (with Cancel + "clear confirmed to
  reuse slot"), Reset Timer, dead-man timer minutes, and push-a-new-code.
- Auto-refreshes every 60s while open; manual Refresh button too.

## Build on GitHub
Same process as Device Care itself:
1. Private repo (can be the same one or a separate one — your call).
   Upload `device-control.zip` to the repo root, and
   `.github/workflows/build.yml` to that exact path.
2. Actions tab -> Build APK -> download `device-control-apk`.
3. `adb install app-debug.apk` on your phone, or just copy the APK over and
   open it.

No special permissions, device admin, or adb setup needed — this is a
normal app, it only talks to Firebase over plain HTTPS.
