package com.util.devicecontrol

// Same Firebase project the tablets check in against. Keep this repo private.
object Config {
    const val FIREBASE_URL = "https://tablets-ed990-default-rtdb.firebaseio.com"
    const val FIREBASE_SECRET = "5sNNx8f5fAQatXE7irshHo7L"
    const val MAX_TABLET_SLOTS = 20
    const val AUTO_REFRESH_MS = 60_000L
}
