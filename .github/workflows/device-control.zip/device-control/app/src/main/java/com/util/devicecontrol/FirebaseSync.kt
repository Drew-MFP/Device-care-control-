package com.util.devicecontrol

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Same REST schema the tablet app's CheckWorker reads/writes — see that
 *  project's FirebaseSync.kt for the full field reference. */
object FirebaseSync {
    fun pull(tabletId: String): JSONObject? {
        if (tabletId.isBlank()) return null
        return try {
            val url = URL("${Config.FIREBASE_URL}/${Config.FIREBASE_SECRET}/tablets/$tabletId.json")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.requestMethod = "GET"
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            conn.disconnect()
            if (body.isBlank() || body == "null") JSONObject() else JSONObject(body)
        } catch (e: Exception) {
            null
        }
    }

    fun push(tabletId: String, fields: Map<String, Any?>): Boolean {
        if (tabletId.isBlank()) return false
        return try {
            val url = URL("${Config.FIREBASE_URL}/${Config.FIREBASE_SECRET}/tablets/$tabletId.json")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.requestMethod = "POST"
            conn.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            val json = JSONObject()
            for ((k, v) in fields) json.put(k, v ?: JSONObject.NULL)
            conn.outputStream.use { it.write(json.toString().toByteArray()) }
            val code = conn.responseCode
            conn.disconnect()
            code in 200..299
        } catch (e: Exception) {
            false
        }
    }
}
