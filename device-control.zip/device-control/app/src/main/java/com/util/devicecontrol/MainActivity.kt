package com.util.devicecontrol

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Native phone counterpart to tablet-switches.html — same Firebase schema,
 * same feature set (remote triggers, pause, disable, reset timer, change
 * code), just as a real app instead of a page you have to open in a browser.
 */
class MainActivity : Activity() {
    private val slots = (1..Config.MAX_TABLET_SLOTS).map { "tablet$it" }
    private lateinit var picker: Spinner
    private lateinit var nicknameField: EditText
    private lateinit var cardContainer: LinearLayout
    private lateinit var footer: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var currentIndex = 0
    private var currentData: JSONObject = JSONObject()

    private val autoRefresh = object : Runnable {
        override fun run() {
            load()
            handler.postDelayed(this, Config.AUTO_REFRESH_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("control", MODE_PRIVATE)
        val savedId = prefs.getString("selected", "tablet1")
        currentIndex = slots.indexOf(savedId).let { if (it >= 0) it else 0 }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 48, 40, 48) }
        val scroll = ScrollView(this).apply { addView(root) }

        root.addView(TextView(this).apply { text = "Device Care Control"; textSize = 22f })
        root.addView(TextView(this).apply {
            text = "Changes apply next time that tablet checks in."
            textSize = 12f; setTextColor(Color.GRAY)
        })

        val pickerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 16, 0, 8) }
        pickerRow.addView(TextView(this).apply { text = "Tablet:  " })
        picker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, slots).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(currentIndex)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        pickerRow.addView(picker)
        root.addView(pickerRow)

        val nickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, 8) }
        nickRow.addView(TextView(this).apply { text = "Nickname:  " })
        nicknameField = EditText(this).apply {
            hint = "e.g. Jill's tablet"
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        nickRow.addView(nicknameField)
        nickRow.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                val text = nicknameField.text?.toString() ?: ""
                val id = tabletId()
                bg {
                    val ok = FirebaseSync.push(id, mapOf("nickname" to text))
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, if (ok) "Nickname saved" else "Could not save — check connectivity", Toast.LENGTH_SHORT).show()
                        if (ok) currentData.put("nickname", text)
                    }
                }
            }
        })
        root.addView(nickRow)

        cardContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(cardContainer)

        root.addView(Button(this).apply { text = "Refresh"; setOnClickListener { load() } })
        footer = TextView(this).apply { textSize = 11f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(0, 8, 0, 0) }
        root.addView(footer)

        picker.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos == currentIndex) return
                currentIndex = pos
                prefs.edit().putString("selected", slots[pos]).apply()
                nicknameField.setText("")
                load()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        })

        setContentView(scroll)
        load()
    }

    override fun onResume() {
        super.onResume()
        handler.postDelayed(autoRefresh, Config.AUTO_REFRESH_MS)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(autoRefresh)
    }

    private fun bg(block: () -> Unit) = Thread(block).start()
    private fun tabletId() = slots[currentIndex]

    private fun load() {
        footer.text = "Loading…"
        val id = tabletId()
        bg {
            val data = FirebaseSync.pull(id)
            runOnUiThread {
                if (data == null) {
                    footer.text = "Could not load — check connectivity"
                } else {
                    currentData = data
                    if (!nicknameField.hasFocus()) {
                        nicknameField.setText(data.optString("nickname", ""))
                    }
                    renderCard()
                    footer.text = "Updated " + SimpleDateFormat("h:mm:ss a", Locale.US).format(Date())
                }
            }
        }
    }

    /** Pushes fields, then optimistically merges them into currentData and
     *  re-renders — same pattern tablet-switches.html uses, so the badge/state
     *  updates immediately instead of waiting for the next auto-refresh. */
    private fun patch(fields: Map<String, Any?>) {
        val id = tabletId()
        bg {
            val ok = FirebaseSync.push(id, fields)
            runOnUiThread {
                if (ok) {
                    for ((k, v) in fields) {
                        when (v) {
                            null -> currentData.put(k, JSONObject.NULL)
                            else -> currentData.put(k, v)
                        }
                    }
                    renderCard()
                } else {
                    Toast.makeText(this, "Could not update $id", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun timeAgo(ts: Long): String {
        if (ts <= 0L) return "never checked in"
        val ms = System.currentTimeMillis() - ts
        if (ms < 0) return "just now"
        val m = ms / 60000; val h = m / 60; val d = h / 24
        return when {
            d > 0 -> "${d}d ${h % 24}h ago"
            h > 0 -> "${h}h ${m % 60}m ago"
            m > 0 -> "${m}m ago"
            else -> "just now"
        }
    }

    private fun badgeView(state: String): TextView = TextView(this).apply {
        textSize = 11f
        setPadding(16, 2, 16, 2)
        val (txt, bg, fg) = when (state) {
            "confirmed" -> Triple("Confirmed", Color.parseColor("#1F16A34A"), Color.parseColor("#16A34A"))
            "pending" -> Triple("Pending", Color.parseColor("#1FD97706"), Color.parseColor("#D97706"))
            else -> Triple("Off", Color.parseColor("#1F6B7280"), Color.parseColor("#6B7280"))
        }
        text = txt
        setTextColor(fg)
        setBackgroundColor(bg)
    }

    private fun row(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, 12, 0, 12)
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text.uppercase()
        textSize = 11f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.GRAY)
        setPadding(0, 28, 0, 4)
    }

    private fun hr() = View(this).apply {
        setBackgroundColor(Color.parseColor("#E0E0E0"))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2).apply { topMargin = 8 }
    }

    /** Confirm dialog before a switch takes effect; Cancel reverts the visual
     *  state without re-prompting or calling onConfirm. */
    private fun confirmSwitch(sw: Switch, label: String, onConfirm: (Boolean) -> Unit) {
        var current = sw.isChecked
        sw.setOnCheckedChangeListener { _, checked ->
            if (checked == current) return@setOnCheckedChangeListener
            AlertDialog.Builder(this)
                .setTitle("Confirm")
                .setMessage("Turn $label ${if (checked) "ON" else "OFF"} for ${tabletId()}?")
                .setPositiveButton("Yes") { _, _ -> current = checked; onConfirm(checked) }
                .setNegativeButton("Cancel") { _, _ -> sw.isChecked = current }
                .setCancelable(false)
                .show()
        }
    }

    private fun renderCard() {
        cardContainer.removeAllViews()
        val d = currentData
        val lastSeen = d.optLong("lastSeen", 0L)
        val stale = lastSeen == 0L || (System.currentTimeMillis() - lastSeen) > 48L * 3_600_000L
        val gkTriggered = d.optBoolean("gatekeepTriggered", false)
        val rpTriggered = d.optBoolean("repeaterTriggered", false)
        val gkActive = d.optBoolean("gatekeepActive", false)
        val rpActive = d.optBoolean("repeaterActive", false)
        val pauseUntil = d.optLong("pauseUntil", 0L)
        val pauseLeftMs = pauseUntil - System.currentTimeMillis()
        val paused = pauseLeftMs > 0
        val disableCmd = d.optBoolean("disable", false)
        val disableConfirmed = d.optBoolean("disableConfirmed", false)
        val disableState = if (disableCmd) (if (disableConfirmed) "confirmed" else "pending") else "off"
        val limitMinutes = if (d.has("limitMinutes") && !d.isNull("limitMinutes")) d.optLong("limitMinutes") else null
        val codeChangeTs = d.optLong("codeChangeTs", 0L)
        val pendingCodeTs = d.optLong("pendingCodeTs", 0L)
        val codeState = if (pendingCodeTs > 0L) (if (codeChangeTs >= pendingCodeTs) "confirmed" else "pending") else "off"

        // Timer on/off and Test Mode: request/applied pair, same pattern as
        // Gatekeep/Repeater — "pending*" is what was last asked for, the
        // plain field is what the tablet last echoed as actually applied.
        val timerOnApplied = d.optBoolean("timerOn", true)
        val timerOnAppliedTs = d.optLong("timerOnTs", 0L)
        val pendingTimerOn = d.optBoolean("pendingTimerOn", timerOnApplied)
        val pendingTimerOnTs = d.optLong("pendingTimerOnTs", 0L)
        val timerBadgeState = if (pendingTimerOn == timerOnApplied && timerOnAppliedTs >= pendingTimerOnTs)
            (if (pendingTimerOn) "confirmed" else "off") else "pending"

        val testModeApplied = d.optBoolean("testModeOn", false)
        val testModeAppliedTs = d.optLong("testModeOnTs", 0L)
        val pendingTestModeOn = d.optBoolean("pendingTestModeOn", testModeApplied)
        val pendingTestModeOnTs = d.optLong("pendingTestModeOnTs", 0L)
        val testModeBadgeState = if (pendingTestModeOn == testModeApplied && testModeAppliedTs >= pendingTestModeOnTs)
            (if (pendingTestModeOn) "confirmed" else "off") else "pending"

        // --- Lock banner ---
        if (gkActive || rpActive) {
            val cause = if (gkActive) d.optString("gatekeepCause", "") else d.optString("repeaterCause", "")
            val causeLabel = when (cause) {
                "remote" -> "a remote command"; "timer" -> "the dead-man timer"; "test" -> "a manual test"; else -> "unknown"
            }
            cardContainer.addView(TextView(this).apply {
                text = (if (gkActive) "🔒 Currently locked — Gatekeep" else "🔁 Currently locked — Repeater") + ", triggered by $causeLabel"
                setBackgroundColor(if (gkActive) Color.parseColor("#1FDC2626") else Color.parseColor("#1FD97706"))
                setPadding(16, 16, 16, 16)
            })
        }

        cardContainer.addView(TextView(this).apply {
            text = "Last check-in: ${timeAgo(lastSeen)}${if (stale && lastSeen > 0) " — may be deleted/uninstalled" else ""}"
            textSize = 12f
            setTextColor(if (stale) Color.parseColor("#D97706") else Color.GRAY)
            setPadding(0, 8, 0, 0)
        })
        if (lastSeen > 0L) {
            cardContainer.addView(Button(this).apply {
                text = "Reset check-in (mark as never checked in)"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Reset check-in?")
                        .setMessage("This clears the last-seen time for ${tabletId()} — use this after you've uninstalled Device Care from that tablet, so it stops showing a stale time. Don't use this if the tablet is still active; it'll look right again on its next real check-in regardless.")
                        .setPositiveButton("Reset") { _, _ -> patch(mapOf("lastSeen" to 0L)) }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            })
        }

        // --- Remote triggers ---
        cardContainer.addView(sectionTitle("Remote triggers"))

        val gkRow = row()
        val gkCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val gkTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        gkTop.addView(TextView(this).apply { text = "Gatekeep  " })
        gkTop.addView(badgeView(if (gkTriggered == gkActive) (if (gkTriggered) "confirmed" else "off") else "pending"))
        gkCol.addView(gkTop)
        gkCol.addView(TextView(this).apply {
            text = if (gkActive) "Active now" else "Not active"; textSize = 11f; setTextColor(Color.GRAY)
        })
        val gkSwitch = Switch(this).apply { isChecked = gkTriggered }
        gkRow.addView(gkCol); gkRow.addView(gkSwitch)
        cardContainer.addView(gkRow)
        confirmSwitch(gkSwitch, "Gatekeep") { checked -> patch(mapOf("gatekeepTriggered" to checked)) }

        val rpRow = row()
        val rpCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val rpTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        rpTop.addView(TextView(this).apply { text = "Repeater  " })
        rpTop.addView(badgeView(if (rpTriggered == rpActive) (if (rpTriggered) "confirmed" else "off") else "pending"))
        rpCol.addView(rpTop)
        rpCol.addView(TextView(this).apply {
            text = if (rpActive) "Active now" else "Not active"; textSize = 11f; setTextColor(Color.GRAY)
        })
        val rpSwitch = Switch(this).apply { isChecked = rpTriggered }
        rpRow.addView(rpCol); rpRow.addView(rpSwitch)
        cardContainer.addView(rpRow)
        confirmSwitch(rpSwitch, "Repeater") { checked -> patch(mapOf("repeaterTriggered" to checked)) }

        // --- Pause ---
        cardContainer.addView(hr())
        cardContainer.addView(sectionTitle("Pause (overrides everything)"))
        cardContainer.addView(TextView(this).apply {
            text = if (paused) "Paused — ${(pauseLeftMs / 60000) + 1} min left" else "Not paused"
        })
        val pauseRow = row()
        val pauseMinutes = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "minutes"
            setText("60")
            layoutParams = LinearLayout.LayoutParams(160, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        pauseRow.addView(pauseMinutes)
        pauseRow.addView(Button(this).apply {
            text = "Pause"
            setOnClickListener {
                val mins = pauseMinutes.text.toString().toLongOrNull() ?: 0L
                if (mins > 0) patch(mapOf("pauseUntil" to (System.currentTimeMillis() + mins * 60000L)))
            }
        })
        pauseRow.addView(Button(this).apply {
            text = "Cancel pause"
            setOnClickListener { patch(mapOf("pauseUntil" to 0L)) }
        })
        cardContainer.addView(pauseRow)

        // --- Disable ---
        cardContainer.addView(hr())
        cardContainer.addView(sectionTitle("Disable this installation"))
        val disableRow = row()
        val disableCol = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        disableCol.addView(TextView(this).apply { text = "Remote disable  " })
        disableCol.addView(badgeView(disableState))
        val disableSwitch = Switch(this).apply { isChecked = disableCmd }
        disableRow.addView(disableCol); disableRow.addView(disableSwitch)
        cardContainer.addView(disableRow)
        confirmSwitch(disableSwitch, "remote disable") { checked -> patch(mapOf("disable" to checked)) }
        val disableBtnRow = row()
        disableBtnRow.addView(Button(this).apply {
            text = "Cancel (before confirmed)"
            setOnClickListener { patch(mapOf("disable" to false)) }
        })
        disableBtnRow.addView(Button(this).apply {
            text = "Clear confirmed (reuse slot)"
            setOnClickListener { patch(mapOf("disable" to false, "disableConfirmed" to false)) }
        })
        cardContainer.addView(disableBtnRow)

        // --- Dead-man timer on/off ---
        cardContainer.addView(hr())
        cardContainer.addView(sectionTitle("Dead-man timer"))
        val timerOnRow = row()
        val timerOnCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val timerOnTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        timerOnTop.addView(TextView(this).apply { text = "Timer on  " })
        timerOnTop.addView(badgeView(timerBadgeState))
        timerOnCol.addView(timerOnTop)
        timerOnCol.addView(TextView(this).apply {
            text = "Tablet reports: ${if (timerOnApplied) "ON" else "OFF"}"; textSize = 11f; setTextColor(Color.GRAY)
        })
        val timerOnSwitch = Switch(this).apply { isChecked = pendingTimerOn }
        timerOnRow.addView(timerOnCol); timerOnRow.addView(timerOnSwitch)
        cardContainer.addView(timerOnRow)
        confirmSwitch(timerOnSwitch, "the dead-man timer") { checked ->
            patch(mapOf("pendingTimerOn" to checked, "pendingTimerOnTs" to System.currentTimeMillis()))
        }

        cardContainer.addView(TextView(this).apply {
            text = "Currently ${limitMinutes ?: "—"} minutes (as of last check-in)"
            textSize = 12f
        })
        val limitRow = row()
        val limitInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "minutes"
            if (limitMinutes != null) setText(limitMinutes.toString())
            layoutParams = LinearLayout.LayoutParams(160, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        limitRow.addView(limitInput)
        limitRow.addView(Button(this).apply {
            text = "Set minutes"
            setOnClickListener {
                val mins = limitInput.text.toString().toLongOrNull()
                if (mins != null && mins > 0) patch(mapOf("limitMinutes" to mins, "limitMinutesTs" to System.currentTimeMillis()))
            }
        })
        cardContainer.addView(limitRow)
        cardContainer.addView(Button(this).apply {
            text = "Reset timer now"
            setOnClickListener { patch(mapOf("resetTimerTs" to System.currentTimeMillis())) }
        })

        // --- Test Mode ---
        cardContainer.addView(hr())
        cardContainer.addView(sectionTitle("Test Mode"))
        cardContainer.addView(TextView(this).apply {
            text = "Gesture/unlock safety timers on the tablet — leave off once gestures are confirmed working."
            textSize = 11f; setTextColor(Color.GRAY)
        })
        val testRow = row()
        val testCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val testTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        testTop.addView(TextView(this).apply { text = "Test Mode  " })
        testTop.addView(badgeView(testModeBadgeState))
        testCol.addView(testTop)
        testCol.addView(TextView(this).apply {
            text = "Tablet reports: ${if (testModeApplied) "ON" else "OFF"}"; textSize = 11f; setTextColor(Color.GRAY)
        })
        val testSwitch = Switch(this).apply { isChecked = pendingTestModeOn }
        testRow.addView(testCol); testRow.addView(testSwitch)
        cardContainer.addView(testRow)
        confirmSwitch(testSwitch, "Test Mode") { checked ->
            patch(mapOf("pendingTestModeOn" to checked, "pendingTestModeOnTs" to System.currentTimeMillis()))
        }

        // --- Change code ---
        cardContainer.addView(hr())
        val codeTitleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        codeTitleRow.addView(sectionTitle("Change code"))
        codeTitleRow.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
        codeTitleRow.addView(badgeView(codeState))
        cardContainer.addView(codeTitleRow)
        val code1 = EditText(this).apply {
            hint = "New code"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        }
        val code2 = EditText(this).apply {
            hint = "Re-enter new code"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        }
        cardContainer.addView(code1); cardContainer.addView(code2)
        cardContainer.addView(Button(this).apply {
            text = "Push new code"
            setOnClickListener {
                val a = code1.text.toString(); val b = code2.text.toString()
                when {
                    a.isBlank() -> Toast.makeText(this@MainActivity, "Enter a code first", Toast.LENGTH_SHORT).show()
                    a != b -> Toast.makeText(this@MainActivity, "Codes don't match", Toast.LENGTH_SHORT).show()
                    else -> patch(mapOf("pendingCode" to a, "pendingCodeTs" to System.currentTimeMillis()))
                }
            }
        })
    }
}
